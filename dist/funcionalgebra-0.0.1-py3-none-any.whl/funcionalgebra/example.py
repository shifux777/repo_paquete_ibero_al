#TEST


import __init__ as a
det2=al.det2x2()
det3=det3x3()
magn=magnitud()
direccion =direccion()
Suma=suma2v()
