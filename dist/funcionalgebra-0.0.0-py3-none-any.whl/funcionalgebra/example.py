#TEST


import import ibero_al as AL
det2=det2x2() 
det3=det3x3()
magn=magnitud()
direccion =direccion()
Suma=suma2v()
